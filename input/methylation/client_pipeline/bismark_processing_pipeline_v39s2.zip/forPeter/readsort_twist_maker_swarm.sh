#!/bin/bash
set -euo pipefail
ml samtools

FULL_BAM="$1"
BED="/data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/CoordSorted/twist_regions_150.hg19.bed"

THREADS="${SLURM_CPUS_PER_TASK:-32}"

[[ -s "$FULL_BAM" ]] || { echo "Missing BAM: $FULL_BAM" >&2; exit 1; }

TISSUE_DIR="$(dirname "$FULL_BAM")"
SAMPLE="$(basename "${FULL_BAM%.bam}")"

OUT_DIR="${TISSUE_DIR}/twist_bams"
mkdir -p "$OUT_DIR"
OUT_BAM="${OUT_DIR}/${SAMPLE}.twist.withmates.readsort.bam"

# per-sample temp names file in scratch
lscratch="${SLURM_TMPDIR:-/tmp}"
NAMES="${lscratch}/${SAMPLE}.twist.names.txt"

samtools view -@ "$THREADS" -L "$BED" "$FULL_BAM" \
  | cut -f1 | LC_ALL=C sort -u > "$NAMES"

samtools view -@ "$THREADS" -N "$NAMES" -bh "$FULL_BAM" \
  | samtools sort -@ "$THREADS" -n -o "$OUT_BAM" -

echo "Done: $FULL_BAM -> $OUT_BAM"



