#!/bin/bash
# A script to make one large feature table from V*.nonCpG_per_read_per_probe.tsv of every sample

#!/bin/bash
set -euo pipefail

#out="all_samples.probe_meth_unfiltered.long.tsv"
# updated out with missing samples included
out="all_samples.probe_meth_unfiltered.long_v2.tsv"

echo -e "sample\tprobe_id\tCpG_meth\tCpG_total\tCpG_frac\tnonCpG_meth\tnonCpG_total\tnonCpG_frac\tn_reads\tn_reads_with_CpG" > "$out"

find /data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/ReadSorted \
  -name "*.nonCpG_per_read_per_probe.tsv" -type f |
while read -r infile; do
  sample="$(basename "$infile" | cut -d. -f1)"

  awk -v sample="$sample" 'BEGIN{FS=OFS="\t"} NR==1{next}
  {
    probe=$2
    mZ[probe]+=$3;  allZ[probe]+=$4
    mNon[probe]+=$12; allNon[probe]+=$13
    n[probe]++
    if($4>0) n_cpg[probe]++
  }
  END{
    for(probe in n){
      cpg_frac=(allZ[probe]>0 ? mZ[probe]/allZ[probe] : "NA")
      non_frac=(allNon[probe]>0 ? mNon[probe]/allNon[probe] : "NA")
      print sample,probe,mZ[probe],allZ[probe],cpg_frac,mNon[probe],allNon[probe],non_frac,n[probe],(probe in n_cpg ? n_cpg[probe] : 0)
    }
  }' "$infile" | sort -k2,2 >> "$out"
done



