#!/bin/bash
set -euo pipefail

ml samtools bedtools perl

BAM="$1"   # e.g. Colon/twist_bams/V23_S8.twist.withmates.readsort.bam
BED="${2:-/data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/CoordSorted/twist_regions_150.hg19.bed}"
THRESH="${3:-8}"   # failing = >THRESH methylated nonCpGs per read (CHG+CHH)

[[ -s "$BAM" ]] || { echo "Missing BAM: $BAM" >&2; exit 1; }

METHDIR="${BAM%.bam}.meth"
[[ -d "$METHDIR" ]] || { echo "Missing meth dir: $METHDIR" >&2; exit 1; }

BASE="$(basename "$BAM")"
SAMPLE="${BASE%%.*}"

CPG=$(ls "$METHDIR"/CpG_context_*.txt.gz | head -n 1)
CHG=$(ls "$METHDIR"/CHG_context_*.txt.gz | head -n 1)
CHH=$(ls "$METHDIR"/CHH_context_*.txt.gz | head -n 1)
[[ -s "$CPG" && -s "$CHG" && -s "$CHH" ]] || { echo "Missing context gz files in $METHDIR" >&2; exit 1; }

# --- A) per-read methyl/unmeth counts (Sara's script fixed) ---
SCRIPT="/data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/ReadSorted/collect_MethUnmeth_cts_per_fragment.fixed.pl"

# Make reruns safe: remove output that perl refuses to overwrite
rm -f "$METHDIR/${SAMPLE}.MethUnmeth_cts_per_fragment.txt"

( cd "$METHDIR" && perl "$SCRIPT" "$CPG" "$CHG" "$CHH" "$SAMPLE" )

PERREAD="$METHDIR/${SAMPLE}.MethUnmeth_cts_per_fragment.txt"
[[ -s "$PERREAD" ]] || { echo "Missing PERREAD output: $PERREAD" >&2; exit 1; }

# --- B) map readID -> probeID using your existing pre-made reads.bed ---
# OPTIONAL: allow user to pass a reads.bed as arg4; otherwise default to methdir
READBED="${4:-$METHDIR/${SAMPLE}.reads.bed}"
[[ -s "$READBED" ]] || {
  echo "Missing reads BED (expected already corrected): $READBED" >&2
  echo "Expected BED columns: chr start end readID (tab-delimited)" >&2
  exit 1
}

READ2PROBE="$METHDIR/${SAMPLE}.read2probe.tsv"

# NOTE:
# - rid is assumed to be column 4 of the reads BED (BED4)
# - probeID is assumed to be column 4 of the TWIST BED
# - If your reads BED is BED6 instead of BED4, pid shifts; we handle BED4 vs BED6 automatically.
bedtools intersect -a "$READBED" -b "$BED" -wa -wb \
  | awk 'BEGIN{OFS="\t"}
         {
           # readID from reads BED (col4)
           rid=$4; sub(/\/[12]$/,"",rid);

           # If -a is BED6, then $6 is strand (+/-) and probeID lands at $10 (6+4).
           # If -a is BED4, probeID lands at $8 (4+4).
           if ($6=="+" || $6=="-") pid=$10; else pid=$8;

           key=rid SUBSEP pid; cnt[key]++
         }
         END{
           for(k in cnt){
             split(k,a,SUBSEP); rid=a[1]; pid=a[2];
             if(cnt[k] > best[rid]){best[rid]=cnt[k]; bestpid[rid]=pid}
           }
           for(rid in bestpid) print rid,bestpid[rid]
         }' \
  | sort -t $'\t' -k1,1 > "$READ2PROBE"

# --- C) join per-read counts to probe, then summarize per probe ---
lscratch="${SLURM_TMPDIR:-${TMPDIR:-$METHDIR}}"
tail -n +2 "$PERREAD" | sort -t $'\t' -k1,1 > "$lscratch/${SAMPLE}.perread.sorted"

PERREAD_PROBE="$METHDIR/${SAMPLE}.nonCpG_per_read_per_probe.tsv"
join -t $'\t' -1 1 -2 1 "$READ2PROBE" "$lscratch/${SAMPLE}.perread.sorted" \
  | awk -v thr="$THRESH" 'BEGIN{
           OFS="\t";
           print "readID","probeID",
                 "mZ","allZ","pctZ",
                 "mX","allX","pctX",
                 "mH","allH","pctH",
                 "mNonCpG","allNonCpG","pctNonCpG",
                 "fail_mNonCpG_gt_"thr
         }
         {
           rid=$1; pid=$2;
           mZ=$3; allZ=$4; pctZ=$5;
           mX=$6; allX=$7; pctX=$8;
           mH=$9; allH=$10; pctH=$11;

           mNC=mX+mH;
           allNC=allX+allH;
           pctNC=(allNC>0?mNC/allNC:"NA");
           fail=(mNC>thr?1:0);

           print rid,pid,mZ,allZ,pctZ,mX,allX,pctX,mH,allH,pctH,mNC,allNC,pctNC,fail
         }' > "$PERREAD_PROBE"

BYPROBE="$METHDIR/${SAMPLE}.nonCpG_by_probe_reads.tsv"
awk 'NR==1{next}
     {
       pid=$2;
       n[pid]++;

       mNC[pid]+=$12;
       allNC[pid]+=$13;

       fail[pid]+=$15;
     }
     END{
       OFS="\t";
       print "probeID","nReads","mNonCpG","allNonCpG","pctNonCpG","nFail","fracFail";
       for(pid in n){
         pct=(allNC[pid]>0?mNC[pid]/allNC[pid]:"NA");
         frac=(n[pid]>0?fail[pid]/n[pid]:"NA");
         print pid,n[pid],mNC[pid],allNC[pid],pct,fail[pid],frac
       }
     }' "$PERREAD_PROBE" | sort -t $'\t' -k1,1 > "$BYPROBE"

echo "Wrote:"
echo "  $PERREAD_PROBE"
echo "  $BYPROBE"


