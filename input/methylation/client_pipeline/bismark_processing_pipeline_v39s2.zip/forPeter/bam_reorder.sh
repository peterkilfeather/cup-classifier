#!/bin/bash
set -euo pipefail

ml bedtools

BAM="$1"   # e.g. Ovary/twist_bams/V39_S9.twist.withmates.readsort.bam
[[ -s "$BAM" ]] || { echo "Missing BAM: $BAM" >&2; exit 1; }

METHDIR="${BAM%.bam}.meth"
mkdir -p "$METHDIR"

# "V39_S9" from "V39_S9.twist.withmates.readsort.bam"
base="$(basename "$BAM" .bam)"
SAMPLE="${base%%.*}"

OUT="$METHDIR/${SAMPLE}.reads.bed"

bedtools bamtobed -i "$BAM" \
  | awk 'BEGIN{OFS="\t"}{rid=$4; sub(/\/[12]$/,"",rid); print $1,$2,$3,rid}' \
  > "$OUT"

echo "Wrote $OUT"



