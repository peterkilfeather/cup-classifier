#!/usr/bin/perl
use strict;
use warnings;

# Usage:
#   perl collect_MethUnmeth_cts_per_fragment.fixed.pl CpG_context*.gz CHG_context*.gz CHH_context*.gz SAMPLEID
#
# Output:
#   SAMPLEID.MethUnmeth_cts_per_fragment.txt (written in current working directory)

my ($fragfileCpG, $fragfileCHG, $fragfileCHH, $sampleID) = @ARGV;
die "USAGE: perl $0 <CpG.gz> <CHG.gz> <CHH.gz> <sampleID>\n" unless defined $sampleID;

for my $f ($fragfileCpG, $fragfileCHG, $fragfileCHH) {
  die "ERROR: missing input file: $f\n" unless -e $f;
}

my $outfile = "$sampleID.MethUnmeth_cts_per_fragment.txt";
die "ERROR: output file already exists: $outfile\n" if -e $outfile;

open(my $OUT, ">", $outfile) or die "ERROR: cannot write $outfile: $!\n";
print $OUT join("\t", "readID",
                "mZ","allZ","pctZ",
                "mX","allX","pctX",
                "mH","allH","pctH"), "\n";

my %reads;

sub ingest_context {
  my ($file, $ctxtUC) = @_;           # ctxtUC is 'Z' or 'X' or 'H'
  my $ctxtLC = lc($ctxtUC);

  open(my $IN, "zcat $file |") or die "ERROR: zcat $file failed: $!\n";
  while (<$IN>) {
    next if /^Bismark/;
    chomp;
    my ($readID, $strand, $chrom, $pos, $mcall) = split(/\t/);
    next unless defined $mcall;

    if    ($mcall eq $ctxtUC) { $reads{$readID}{$ctxtUC}{M}++; }
    elsif ($mcall eq $ctxtLC) { $reads{$readID}{$ctxtUC}{U}++; }
  }
  close($IN);
}

print STDERR "Reading CpG ($sampleID)\n";
ingest_context($fragfileCpG, 'Z');

print STDERR "Reading CHG ($sampleID)\n";
ingest_context($fragfileCHG, 'X');

print STDERR "Reading CHH ($sampleID)\n";
ingest_context($fragfileCHH, 'H');

for my $readID (keys %reads) {
  my @row = ($readID);
  for my $ctxt (qw(Z X H)) {
    my $m = 0 + ($reads{$readID}{$ctxt}{M} // 0);
    my $u = 0 + ($reads{$readID}{$ctxt}{U} // 0);
    my $t = $m + $u;
    my $pct = ($t > 0) ? sprintf("%.3f", $m/$t) : "NA";
    push @row, $m, $t, $pct;
  }
  print $OUT join("\t", @row), "\n";
}

close($OUT);
print STDERR "Wrote $outfile\n";


