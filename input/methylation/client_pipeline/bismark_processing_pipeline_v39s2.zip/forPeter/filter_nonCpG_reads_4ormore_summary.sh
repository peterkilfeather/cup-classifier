#!/bin/bash
set -euo pipefail

cd /data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/ReadSorted

out="filter_nonCpG_reads_4ormore_summary_v2.tsv"
echo -e "sample\ttissue\tinput_reads\tkept_reads\tremoved_reads\tremoved_frac" > "$out"

find . -type f -name "*.nonCpG_per_read_per_probe.tsv" ! -name "*.mNonCpGlt4.tsv" -print0 \
| while IFS= read -r -d '' f; do
    kept="${f%.tsv}.mNonCpGlt4.tsv"

    sample="$(basename "$f" .nonCpG_per_read_per_probe.tsv)"
    tissue="$(echo "$f" | cut -d'/' -f2)"   

    in_reads=$(awk 'END{print NR-1}' "$f")          # minus header
    kept_reads=$(awk 'END{print NR-1}' "$kept")     # minus header
    removed=$((in_reads - kept_reads))

    removed_frac=$(awk -v r="$removed" -v n="$in_reads" 'BEGIN{if(n>0) printf "%.6f", r/n; else print "NA"}')

    echo -e "${sample}\t${tissue}\t${in_reads}\t${kept_reads}\t${removed}\t${removed_frac}" >> "$out"
  done



