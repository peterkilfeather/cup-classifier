#!/bin/bash
set -euo pipefail

cd /data/farneysk/ElnitskiLab/Bismark_Output/WGEmSeq/seq_files/EMseq_BAMs/ReadSorted

find . -type f -name "*.nonCpG_per_read_per_probe.tsv" -print0 \
| while IFS= read -r -d '' f; do
    out="${f%.tsv}.mNonCpGlt4.tsv"
    awk 'BEGIN{FS=OFS="\t"} NR==1{print; next} ($12 < 4){print}' "$f" > "$out"
  done


