#!/bin/bash
set -euo pipefail

# Script usage example: ./methylextractor_mbias.sh ReadSorted/Ovary/V39_S2.readsort.twist.bam mbias
# Or: ./methylextractor_mbias.sh ReadSorted/Ovary/V39_S2.readsort.twist.bam extract

threads="${SLURM_CPUS_PER_TASK:-24}"

# Bismark notes ~3 cores per --multicore value; aim to stay within allocation
mc=$(( threads / 3 ))
(( mc < 1 )) && mc=1

BAM="$1"
MODE="${2:-extract}"   # "mbias" or "extract"

[[ -s "$BAM" ]] || { echo "Missing BAM: $BAM" >&2; exit 1; }

outdir="${BAM%.bam}.meth"
mkdir -p "$outdir"

module load bismark samtools
GENOME_FOLDER="/fdb/bismark/hg19"

# shared settings (keep consistent between mbias + extract)
COMMON_ARGS=(
  --paired-end --no_overlap --comprehensive
  --ignore 4 --ignore_r2 3 --ignore_3prime_r2 1
  --multicore "$mc"
  --genome_folder "$GENOME_FOLDER"
  --output "$outdir"
)

if [[ "$MODE" == "mbias" ]]; then
  bismark_methylation_extractor \
    "${COMMON_ARGS[@]}" \
    --mbias_only \
    "$BAM"
else
  bismark_methylation_extractor \
    "${COMMON_ARGS[@]}" \
    --bedGraph --counts --gzip \
    "$BAM"
fi

echo "Done ($MODE): $BAM -> $outdir"

























































